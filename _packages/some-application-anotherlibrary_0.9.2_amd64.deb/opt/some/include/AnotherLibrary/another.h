#ifndef ANOTHER_H
#define ANOTHER_H

namespace sm
{
    namespace lbrAnother
    {
        void printSomething();
    }
}

#endif // ANOTHER_H
