#ifndef SOME_H
#define SOME_H

namespace sm
{
    namespace lbrSome
    {
        void printSomething();
    }
}

#endif // SOME_H
